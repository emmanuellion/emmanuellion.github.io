#include <iostream>

int main() {
	char calc[20];
	char i;
	char parenth;
	char antiparenth;
	printf("Ecrivez votre calcul :\n");
	gets(calc);
	while(i<20){
		if(calc[i]=='('){
			parenth++;
		}
		else{
			if(calc[i]==')'){
				antiparenth++;
			}
		}
	i++;
	}
	if(parenth>antiparenth){
		printf("Il y a des parenth�ses ouvrantes en trop !");
	}
	else{
		if(antiparenth>parenth){
			printf("Il y a des parenth�ses fermantes en trop !");
		}
	else{
		printf("Le calcul est bon !");
	}
	}
}
