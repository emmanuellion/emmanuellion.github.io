#include <iostream>

int main() {
	char calc[20];
	char i;
	char parenth;
	char antiparenth;
	printf("Ecrivez votre calcul :\n");
	gets(calc);
	while(i<20){
		if(calc[i]=='('){
			parenth++;
		}
		else{
			if(calc[i]==')'){
				antiparenth++;
			}
		}
	i++;
	}
	if(parenth>antiparenth){
		printf("\nIl y a des parentheses ouvrantes en trop ! Ou des parentheses fermantes en moins.\n");
	}
	else{
		if(antiparenth>parenth){
			printf("\nIl y a des parentheses fermantes en trop ! Ou des partenheses ouvrantes en moins.\n");
		}
	else{
		printf("\nLe calcul est bon !\n");
	}
	}
	printf("\n%i parenthese(s) ouvrante(s) : %i parenthese(s) fermante(s)",parenth,antiparenth);
}
