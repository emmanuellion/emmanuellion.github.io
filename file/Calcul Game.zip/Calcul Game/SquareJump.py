def game(event):
    from random import randint
    global Continue,MaybeMultiply1,Multiply,framgame
    Continue = True
    MaxRadint = 9
    if Continue:
        framgame = Frame(Windows, bg="#151D21")
        framgame.pack()
        frambegin.pack_forget()
        MaxRadint += 1
        NumberInput = int(Entrys.get())
        Multiply = randint(1,MaxRadint)
        Number = NumberInput #conversion de NumberInput d'un str vers un int
        labelChoice = Label(framgame, text="Nombre choisit : " + str(NumberInput), bg="#151D21", font=("Arial",20), fg="red")
        labelChoice.pack()
        NumberOutput = Number * Multiply
        labelResult = Label(framgame, text="Résultat : " + str(NumberOutput), bg="#151D21", fg="red", font=("Arial",20))
        labelResult.pack()
        question1 = Label(framgame, text="Quel est le multiplicateur ?", bg="#151D21", fg="red", font=("Arial",20))
        question1.pack()
        entryQ1 = Entry(framgame, bg="#151D21", fg="red", font=("Arial",20))
        entryQ1.pack()
        entryQ1.bind("<Return>",Suite)
        MaybeMultiply1 = entryQ1
        buttonValidate = Button(framgame, text="Valider", bg="#151D21", fg="red", font=("Arial",20), command=Suite)
        buttonValidate.pack()


def Suite(event):
    global framsuite
    framsuite = Frame(Windows, bg="#151D21")
    framsuite.pack()
    global MaybeMultiply1,Multiply,Continue,choice,GoodAnswer,BadAnswer
    framgame.pack_forget()
    if str(MaybeMultiply1.get()) == str(Multiply):
        Bj = Label(framsuite, text="bien joué", font=("Arial",20), fg="red", bg="#151D21")
        Bj.pack()
        GoodAnswer += 1
    else:
        Dmg = Label(framsuite, text="Dommage...Essaye encore!", fg="red", font=("Arial",20), bg="#151D21")
        Dmg.pack()
        BadAnswer += 1
    space = Label(framsuite, bg="#151D21", text=" oui ", font=("Arial", 5), fg="#151D21")
    space.pack()
    poursuite = Button(framsuite, text="Continuer", fg="red", font=("Arial",20), bg="#151D21", command=begin)
    poursuite.pack()
    nend = Button(framsuite, text="Résultats", fg="red", bg="#151D21", font=("Arial",21), command=end)
    nend.pack()


def end():
    global Continue,GoodAnswer,BadAnswer,framend
    framend = Frame(Windows, bg="#151D21")
    framend.pack()
    framsuite.pack_forget()
    Continue = False
    ga = Label(framend, text="Vous avez eu " + str(GoodAnswer) + " BONNE(S) réponse(s)", fg="red", bg="#151D21",font=("Arial", 17))
    ba = Label(framend, text="Vous avez eu " + str(BadAnswer) + " MAUVAISE(S) réponse(s)", fg="red", bg="#151D21",font=("Arial", 17))
    ga.pack()
    ba.pack()
    FIN = Button(framend, text="FIN", bg="#151D21", font=("Arial", 20), fg="red", command=Windows.destroy)
    FIN.pack()


def begin():
    global Entrys,frambegin,framsuite,framgame
    frambegin.pack_forget()
    framend.pack_forget()
    framsuite.pack_forget()
    framgame.pack_forget()
    frambegin = Frame(Windows, bg="#151D21")
    frambegin.pack()
    labelEntry = Label(frambegin, text="Entrez un nombre :", font=("Arial", 20), fg="red", bg="#151D21")
    labelEntry.pack()
    Entrys = Entry(frambegin, font=("Arial",20), fg="red", bg="#151D21")
    Entrys.pack()
    Entrys.bind("<Return>",game)
    buttonbegin = Button(frambegin, text="Confirmer", font=("Arial", 15), fg="red", bg="#151D21", command=game)
    buttonbegin.pack()


from tkinter import *
Windows = Tk()
framend = Frame(Windows, bg="#151D21")
framgame = Frame(Windows, bg="#151D21")
framsuite = Frame(Windows, bg="#151D21")
frambegin = Frame(Windows, bg="#151D21")
Entrys = 0
GoodAnswer = 0
BadAnswer = 0
choice = "oui"
Continue = True
MaybeMultiply1 = 0
Multiply = 0

if __name__ == '__main__':
   Windows.title("SquareJump") #définie le nom de la fenêtre
   Windows.geometry("1366x768") #définie la taille de la fenêtre au début
   Windows.minsize(480, 360) #définie la taille minimale de la fenêtre
   Windows.iconbitmap("logo.ico") #place dans l'angle supérieur gauche le petit logo
   Windows.config(background="#151D21") #configure la couleur de la fenêtre
   title = Label(Windows, text="Game", font=("Arial",50), fg="red", bg="#151D21")
   title.pack()
   print("*****","\n**H**","\n**E**","\n**L**","\n**L**","\n**O**","\n*****")
   begin()
   Windows.mainloop()

